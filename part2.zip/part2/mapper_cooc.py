#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#!/usr/bin/env python
"""mapper.py"""

import sys

topWords = []

for line in sys.stdin:
    line = line.strip()
    words = line.split()
    topWords = ["republican", "news", "photo", "democrat", "state", "president", "trump", "party", "senate","vote"]
    for iw, w in enumerate(words):
        if w in topWords:
            for iu, u in enumerate(words):
                if(iw != iu):
                    if u in topWords:
                        print '%s\t%s' % ("("+w+","+u+")", 1)                        

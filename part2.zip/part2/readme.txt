here there are 4 files, mapper, mapper_cooc, reducer, and reducer_cooc.
mapper and reducer codes contain the algo for word count
and the other two have the code for word cooccurrence.